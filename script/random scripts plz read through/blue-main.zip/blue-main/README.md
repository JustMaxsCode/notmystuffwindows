# CPP Cyber Blue Team Things

EVEN AT MY LOIS IM GRIFFIN IT ALL
![FQoCsIMVQAMLhZQ](https://github.com/cpp-cyber/blue/assets/68256613/f3e2eb1c-ca70-49f6-92ea-a816b050ac2e)

# Drinking the fabric of reality

![image_2024-04-16_195908966](https://github.com/cpp-cyber/blue/assets/68256613/3af4639d-11f1-461a-8587-210de28a89e4)

# we have 1000000 slas

![image_2024-04-16_195930863](https://github.com/cpp-cyber/blue/assets/68256613/a146a0d3-f7ab-4da4-aa95-1b5ce3f0d37d)
