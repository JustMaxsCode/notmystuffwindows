#!/bin/sh
# @d_tranman/Nigel Gerald/Nigerald

diff /etc/passwd /root/.cache/users
