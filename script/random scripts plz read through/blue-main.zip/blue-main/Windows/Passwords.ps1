Dear RedTeam,
    pls follow me on twitter i need clout https://twitter.com/Altoid0day
Sincerely,
    Your favorite mint Altoid0